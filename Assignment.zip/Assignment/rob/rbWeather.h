//
//  rbTweet.h
//  rob
//
//  Created by media temp on 04/11/2014.
//  Copyright (c) 2014 media temp. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface rbWeather : NSObject

@property (nonatomic, strong) NSString *date;
@property (nonatomic, strong) NSString *city;
@property (nonatomic, strong) NSString *hum;
@property (nonatomic, strong) NSString *wind;
@property (nonatomic, strong) NSString *temp;
@property (nonatomic, strong) UIImage *image;

@end
